<!-- <?php
return[
	
	[
		'label' => 'Quản Lí Kiểu Loại',
		'route' => 'product.adminshow',
		'icon' => 'fa-showname',
		'item' => [
			[
				'label' => 'Kiểu sản phẩm',
				'route' => 'product.adminshow',
			],
			[
				'label' => 'loại sản phẩm',
				'route' => 'product.create',
			],
		]
	],
	[
		'label' => 'Quản Lí Sản Phẩm',
		'route' => 'product.adminshow',
		'icon' => 'fa-showname',
		'item' => [
			[
				'label' => 'Quản Lí Sản Phẩm',
				'route' => 'product.adminshow',
			]
			
		]
	],
	[
		'label' => 'Quản Lí Nhân Sự',
		'route' => 'product.adminshow',
		'icon' => 'fa-showname',
		'item' => [
			[
				'label' => 'User',
				'route' => 'product.adminshow',
			]
			
		]
	],
	[
		'label' => 'Quản Lí Đơn Hàng',
		'route' => 'product.adminshow',
		'icon' => 'fa-showname',
		'item' => [
			[
				'label' => 'Đơn Hàng New',
				'route' => 'product.adminshow',
			],
			[
				'label' => 'Đơn Hàng Old',
				'route' => 'product.adminshow',
			],
			
		]
	],
	[
		'label' => 'Contact',
		'admin' => 'product.adminshow',
		'icon' => 'fa-showname',
		'item' => [
			[
				'label' => 'Contact',
				'route' => 'product.adminshow',
			],
		]
	]



]
?> -->