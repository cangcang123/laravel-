@extends('admin.playout.master')
@section('content')
<h1>{{$masser}}</h1>   
@stop