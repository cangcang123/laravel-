@extends('admin.playout.master')
@section('content')
<h1>Chào Mừng Bạn Đến Với Trang Chủ</h1>   
@stop