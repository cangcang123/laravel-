
<h1>ở đây nè11111111111111</h1>
                    
<?php /**PATH C:\wamp64\www\laravel\resources\views/admin/playout/content.blade.php ENDPATH**/ ?>