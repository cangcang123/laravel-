
<?php $__env->startSection('content'); ?>
 <div class="content-wrapper">
          <div class="content">
          		<div class="row">
<div class="col-lg-6">	<div class="card card-default">
										<div class="card-header card-header-border-bottom">
											<h2>Form pill</h2>
										</div>
										<div class="card-body">
											<form class="form-pill" action="<?php echo e(route('admin.createlist',$id)); ?>" method="POST" role="form">
												<?php echo csrf_field(); ?> 
												<div class="form-group">
													<label for="exampleFormControlInput3">Tên Loại</label>
													<input type="text" class="form-control" id="exampleFormControlInput3" placeholder="Tên Loại" name="name">
												</div>
												<div class="form-group">
													<label for="exampleFormControlSelect3">Kiểu Sản Phẩm</label>
													<select class="form-control" id="exampleFormControlSelect3" name="idname">
														<?php $__currentLoopData = $name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<option value="<?php echo e($n->id); ?>"><?php echo e($n->name); ?></option>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</select>
												</div>
												<button type="submit" name="add" class="btn btn-primary ml-2">Submit</button>
											</form>
										</div>
									</div>
								</div>
									</div>
</div>

          


        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.playout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel\resources\views/admin/Addlist.blade.php ENDPATH**/ ?>