        <section class="featured spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title">
                        <h2>Đồ Tươi</h2>
                    </div>
                    <div class="featured__controls">
                        <ul>
                            <li class="active" data-filter="*">Toàn Bộ</li>
                            <li data-filter=".oranges">Thịt</li>
                            <li data-filter=".fresh-meat">Cá</li>
                            <li data-filter=".vegetables">Gà</li>
                            <li data-filter=".fastfood">Hải Sản</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row featured__filter">
                <?php $__currentLoopData = $thit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-4 col-sm-6 mix oranges ">
                    <div class="featured__item">
                        <div class="featured__item__pic set-bg" href="<?php echo e(route('home.product',$a->id)); ?>"  data-setbg="<?php echo e(asset('images')); ?>/<?php echo e($a->images); ?>">
                            <ul class="featured__item__pic__hover">
                                <li><a href="#"><i class="fa fa-heart"></i></a></li>
                                <li><a href="#"><i class="fa fa-retweet"></i></a></li>
                                <li><a href="<?php echo e(route('cart.homeadd',$a->id)); ?>"><i class="fa fa-shopping-cart"></i></a></li>
                            </ul>
                        </div>
                        <div class="featured__item__text">
                            <h6><a href="<?php echo e(route('home.product',$a->id)); ?>"><?php echo e($a->name); ?></a></h6>
                            <h5><?php echo e(number_format($a->price).' '.'vnđ'); ?></h5>
                        </div>
                    </div>              
                </div>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 <?php $__currentLoopData = $ca; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="col-lg-3 col-md-4 col-sm-6 mix fresh-meat">
                    <div class="featured__item">
                        <div class="featured__item__pic set-bg" href="<?php echo e(route('home.product',$a->id)); ?>"  data-setbg="<?php echo e(asset('images')); ?>/<?php echo e($a->images); ?>">
                            <ul class="featured__item__pic__hover">
                                <li><a href="#"><i class="fa fa-heart"></i></a></li>
                                <li><a href="#"><i class="fa fa-retweet"></i></a></li>
                                <li><a href="<?php echo e(route('cart.homeadd',$a->id)); ?>"><i class="fa fa-shopping-cart"></i></a></li>
                            </ul>
                        </div>
                        <div class="featured__item__text">
                            <h6><a href="<?php echo e(route('home.product',$a->id)); ?>"><?php echo e($a->name); ?></a></h6>
                            <h5><?php echo e(number_format($a->price).' '.'vnđ'); ?></h5>
                        </div>
                    </div>              
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $ga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="col-lg-3 col-md-4 col-sm-6 mix vegetables">
                   <div class="featured__item">
                        <div class="featured__item__pic set-bg" href="<?php echo e(route('home.product',$a->id)); ?>"  data-setbg="<?php echo e(asset('images')); ?>/<?php echo e($a->images); ?>">
                            <ul class="featured__item__pic__hover">
                                <li><a href="#"><i class="fa fa-heart"></i></a></li>
                                <li><a href="#"><i class="fa fa-retweet"></i></a></li>
                                <li><a href="<?php echo e(route('cart.homeadd',$a->id)); ?>"><i class="fa fa-shopping-cart"></i></a></li>
                            </ul>
                        </div>
                        <div class="featured__item__text">
                            <h6><a href="<?php echo e(route('home.product',$a->id)); ?>"><?php echo e($a->name); ?></a></h6>
                            <h5><?php echo e(number_format($a->price).' '.'vnđ'); ?></h5>
                        </div>
                    </div>              
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $haisan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="col-lg-3 col-md-4 col-sm-6 mix fastfood">
                   <div class="featured__item">
                        <div class="featured__item__pic set-bg" href="<?php echo e(route('home.product',$a->id)); ?>"  data-setbg="<?php echo e(asset('images')); ?>/<?php echo e($a->images); ?>">
                            <ul class="featured__item__pic__hover">
                                <li><a href="#"><i class="fa fa-heart"></i></a></li>
                                <li><a href="#"><i class="fa fa-retweet"></i></a></li>
                                <li><a href="<?php echo e(route('cart.homeadd',$a->id)); ?>"><i class="fa fa-shopping-cart"></i></a></li>
                            </ul>
                        </div>
                        <div class="featured__item__text">
                            <h6><a href="<?php echo e(route('home.product',$a->id)); ?>"><?php echo e($a->name); ?></a></h6>
                            <h5><?php echo e(number_format($a->price).' '.'vnđ'); ?></h5>
                        </div>
                    </div>              
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!-- Featured Section End -->

    <!-- Banner Begin -->
    <div class="banner">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="banner__pic">
                        <img src="<?php echo e(asset('site/img/banner/banner-1.jpg')); ?>" alt="">
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="banner__pic">
                        <img src="<?php echo e(asset('site/img/banner/banner-2.jpg')); ?>" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Banner End -->
        <?php /**PATH C:\wamp64\www\laravel\resources\views/components/content.blade.php ENDPATH**/ ?>