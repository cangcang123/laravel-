 <section class="hero">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="hero__categories">
                        <div class="hero__categories__all">
                            <i class="fa fa-bars"></i>
                            <span>All Sản Phẩm</span>
                        </div>
                        
                        <ul>
                            <?php $__currentLoopData = $name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(route('home.name',$n->id)); ?>"><?php echo e($n->name); ?></a></li>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul> 
                       
                    </div>

                </div>
                <div class="col-lg-9">
                    <div class="hero__search">
                        <div class="hero__search__form">
                           <form action="<?php echo e(route('home.search')); ?>"  method="POST">
                            <?php echo csrf_field(); ?>
                                <div class="hero__search__categories">
                                    All Sản Phẩm
                                    <span class="arrow_carrot-down"></span>
                                </div>
                                <input type="text" name="name" placeholder="What do yo u need?">
                                <button type="submit" name="timkiem" class="site-btn">SEARCH</button>
                            </form>
                        </div>
                        <div class="hero__search__phone">
                            <div class="hero__search__phone__icon">
                                <i class="fa fa-phone"></i>
                            </div>
                            <div class="hero__search__phone__text">
                                <h5>+0363566937</h5>
                                <span>Hỗ Trợ 24/7</span>
                            </div>
                        </div>
                    </div>
                    <div class="hero__item set-bg" data-setbg="<?php echo e(asset('site/img/hero/banner.jpg')); ?>">
                        <div class="hero__text">
                            <span>Rau Củ Quả</span>
                            <h2>Tự Nhiên  <br />100% Tươi</h2>
                            <p>Tha Hồ Lựa Chọn , Đảm Bảo Về Hình Ảnh</p>
                            <a href="<?php echo e(route('home.index')); ?>" class="primary-btn">SHOP NOW</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section><?php /**PATH C:\wamp64\www\laravel\resources\views/components/menu.blade.php ENDPATH**/ ?>