<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Ogani Template">
    <meta name="keywords" content="Ogani, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ogani | Template</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;300;400;600;900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('site/css/bootstrap.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('site/css/font-awesome.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('site/css/elegant-icons.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('site/css/nice-select.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('site/css/jquery-ui.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('site/css/owl.carousel.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('site/css/slicknav.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('site/css/style.css')); ?>" type="text/css">
    <link href="<?php echo e(asset('assets/plugins/toaster/toastr.min.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(asset('assets/plugins/nprogress/nprogress.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(asset('assets/plugins/flag-icons/css/flag-icon.min.css')); ?>" rel="stylesheet"/>
  <link href="<?php echo e(asset('assets/plugins/jvectormap/jquery-jvectormap-2.0.3.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(asset('assets/plugins/ladda/ladda.min.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(asset('assets/plugins/daterangepicker/daterangepicker.css')); ?>" rel="stylesheet" />

  <!-- SLEEK CSS -->
  <link id="sleek-css" rel="stylesheet" href="<?php echo e(asset('assets/css/sleek.css')); ?>" />

  

  <!-- FAVICON -->
  <link href="<?php echo e(asset('assets/img/favicon.png')); ?>" rel="shortcut icon" />

</head>

<body>
    <?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Header::class, []); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginald0b4154eafa6ddf1d90e70a636ac005452fbb4c9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Menu::class, []); ?>
<?php $component->withName('menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginald0b4154eafa6ddf1d90e70a636ac005452fbb4c9)): ?>
<?php $component = $__componentOriginald0b4154eafa6ddf1d90e70a636ac005452fbb4c9; ?>
<?php unset($__componentOriginald0b4154eafa6ddf1d90e70a636ac005452fbb4c9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal6ee5fb804927a3b3bdf60037082173f3fd53cef3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Content::class, []); ?>
<?php $component->withName('content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal6ee5fb804927a3b3bdf60037082173f3fd53cef3)): ?>
<?php $component = $__componentOriginal6ee5fb804927a3b3bdf60037082173f3fd53cef3; ?>
<?php unset($__componentOriginal6ee5fb804927a3b3bdf60037082173f3fd53cef3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalfb1aa0eecf6db69d68b59a00d7a39d9fd1c2ae81 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Main::class, []); ?>
<?php $component->withName('main'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalfb1aa0eecf6db69d68b59a00d7a39d9fd1c2ae81)): ?>
<?php $component = $__componentOriginalfb1aa0eecf6db69d68b59a00d7a39d9fd1c2ae81; ?>
<?php unset($__componentOriginalfb1aa0eecf6db69d68b59a00d7a39d9fd1c2ae81); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
     <?php if (isset($component)) { $__componentOriginal157d7c019947a14453c4462247cf8798af5b4b05 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Menuend::class, []); ?>
<?php $component->withName('menuend'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal157d7c019947a14453c4462247cf8798af5b4b05)): ?>
<?php $component = $__componentOriginal157d7c019947a14453c4462247cf8798af5b4b05; ?>
<?php unset($__componentOriginal157d7c019947a14453c4462247cf8798af5b4b05); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <!-- Js Plugins -->/
     <script>
                var d = new Date();
                var year = d.getFullYear();
                document.getElementById("copy-year").innerHTML = year;
            </script>
    <script src="<?php echo e(asset('site/js/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('site/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('site/js/jquery.nice-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('site/js/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('site/js/jquery.slicknav.js')); ?>"></script>
    <script src="<?php echo e(asset('site/js/mixitup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('site/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('site/js/main.js')); ?>"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDCn8TFXGg17HAUcNpkwtxxyT9Io9B_NcM" defer></script>
<script src="<?php echo e(asset('assets/plugins/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/toaster/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/slimscrollbar/jquery.slimscroll.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/charts/Chart.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/ladda/spin.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/ladda/ladda.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/jquery-mask-input/jquery.mask.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/select2/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/jvectormap/jquery-jvectormap-2.0.3.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/jvectormap/jquery-jvectormap-world-mill.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/daterangepicker/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/daterangepicker/daterangepicker.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/jekyll-search.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/sleek.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/chart.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/date-range.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/map.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>



</body>

</html><?php /**PATH C:\wamp64\www\laravel\resources\views/playout/master.blade.php ENDPATH**/ ?>