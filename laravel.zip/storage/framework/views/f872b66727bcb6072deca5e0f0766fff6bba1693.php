
<?php $__env->startSection('content'); ?>
 <div class="row">
                <div class="col-12">
                  <!-- Recent Order Table -->
                  <div class="card card-table-border-none" id="recent-orders">
                    <div class="card-header justify-content-between">
                      <h2>Recent Orders</h2>
                      <div>
                        <span><button type="button" class="mb-1 btn btn-info"><a style="color:#212529" href="<?php echo e(route('admin.Addproductall')); ?>">Thêm Sản Phẩm</a></button>
                          </span>
                      </div>
                    </div>
                    <div class="card-body pt-0 pb-5">
                      <table class="table card-table table-responsive table-responsive-large" style="width:100%">
                        <thead>
                          <tr>
                            <th>Ảnh</th>
                            <th>Tên Sản Phẩm</th>
                            <th class="d-none d-md-table-cell">Số Lượng</th>
                            <th class="d-none d-md-table-cell">Date</th>
                            <th class="d-none d-md-table-cell">price</th>
                            <th>sales</th>
                            <th>Status</th>
                            <th></th>
                          </tr>
                        </thead>
                        <?php $__currentLoopData = $name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tbody>
                          <tr>
                            <td ><img src="<?php echo e(asset('images')); ?>/<?php echo e($n->images); ?>" height="80" width="80"></td>
                            <td >
                              <a class="text-dark" href=""><?php echo e($n->name); ?></a>
                            </td>
                            <td class="d-none d-md-table-cell"><?php echo e($n->quantity); ?></td>
                            <td class="d-none d-md-table-cell"><?php echo e($n->date); ?></td>
                            <td class="d-none d-md-table-cell"><?php echo e($n->price); ?></td>
                            <td><?php echo e($n->sales); ?></td>
                            <td ><?php if($n->sales == 1): ?>{
                              <span class="badge badge-success">Còn Hàng</span>
                            }<?php endif; ?>
                            <span class="badge badge-warning">Hết Hàng</span>
                          
                          
                            </td>
                            <td class="text-right">
                              <div class="dropdown show d-inline-block widget-dropdown">
                                <a class="dropdown-toggle icon-burger-mini" href="" role="button" id="dropdown-recent-order1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-display="static"></a>
                                <ul class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdown-recent-order1">
                                  <li class="dropdown-item">
                                    <a href="<?php echo e(route('admin.editproduct',$n->id)); ?>">Sửa</a>
                                  </li>
                                  <li class="dropdown-item">
                                    <a href="<?php echo e(route('admin.deleteproduct',$n->id)); ?>">Xóa</a>
                                  </li>
                                </ul>
                              </div>
                            </td>
                          </tr>
                        </tbody>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </table>
                    </div>
                    <div>
                      <?php echo e($name->links()); ?>

                    </div>
                  </div>
</div>
              </div>            
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.playout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel\resources\views/admin/product/showproduct.blade.php ENDPATH**/ ?>