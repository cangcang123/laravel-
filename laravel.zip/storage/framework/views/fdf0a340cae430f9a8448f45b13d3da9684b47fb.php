
<?php $__env->startSection('content'); ?>
 <div class="content-wrapper">
          <div class="content">
          		<div class="row">
<div class="col-lg-6">	<div class="card card-default">
										<div class="card-header card-header-border-bottom">
											<h2>Form pill</h2>
										</div>
										<div class="card-body">
											<?php $__currentLoopData = $name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<form class="form-pill" action="<?php echo e(route('admin.updatelist_name',$id)); ?>" method="POST" enctype="multipart/form-data">
												<?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
												<input type="hidden" value="<?php echo e($n->id); ?>" name="idz">
												<div class="form-group">
													<label for="exampleFormControlInput3">Tên Loại</label>
													<input type="text" class="form-control" id="exampleFormControlInput3" value="<?php echo e($n->name); ?>" placeholder="Tên Sản Phẩm" name="name">
												</div>
												
												<div class="form-group">
													<label for="exampleFormControlSelect3">Kiểu Sản Phẩm</label>
													<select class="form-control" id="exampleFormControlSelect3"  name="idname">
														<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<option value="<?php echo e($l->id); ?>"><?php echo e($l->name); ?></option>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</select>
												</div>
												<button type="submit" name="add" class="btn btn-primary ml-2">Submit</button>
											</form>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</div>
									</div>
								</div>
									</div>
</div>

          


        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.playout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel\resources\views/admin/list_name/updatelist.blade.php ENDPATH**/ ?>