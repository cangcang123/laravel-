
<?php $__env->startSection('content'); ?>
<h1>Chào Mừng Bạn Đến Với Trang Chủ</h1>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.playout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel\resources\views/admin/home.blade.php ENDPATH**/ ?>