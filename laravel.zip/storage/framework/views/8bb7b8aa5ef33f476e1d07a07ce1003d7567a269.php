
<?php $__env->startSection('content'); ?>
 <div class="content-wrapper">
          <div class="content">
 <div class="breadcrumb-wrapper">
                <h1>Quản Lí Kiểu Sản Phẩm</h1>             
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb p-0">
            <li class="breadcrumb-item">
              <a href="index.html">
                <span class="mdi mdi-home"></span>                
              </a>
            </li>
            <li class="breadcrumb-item">
              Quản Lí Kiểu Loại
            </li>
            <li class="breadcrumb-item" aria-current="page">Quản Lí Kiểu</li>
          </ol>
        </nav>
             </div> 
 <div class="row">
                <div class="col-lg-6">
                  <div class="card card-default">
                    <div class="card-header card-header-border-bottom">
                      <h2>Bản Quản Lí</h2>
                    </div>
                    <div class="card-body">
                     
<table class="table">
                        <thead>
                          <tr>
                            <th scope="col">stt</th>
                            <th scope="col">Tên Kiểu</th>
                            <th scope="col"><a href="<?php echo e(route('admin.addname')); ?>">thêm</a></th>
                          </tr>
                        </thead>
                        <?php $__currentLoopData = $name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tbody>
                          <tr class="table-danger">
                            <td scope="row"><?php echo e($n->id); ?></td>
                            <td><?php echo e($n->name); ?></td>
                            <td><a href="<?php echo e(route('admin.showlist',$n->id)); ?>">Xem</a></td>
                            <td><a href="<?php echo e(route('admin.editname',$n->id)); ?>">Sửa</a></td>
                          </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                      </div>
                  </div>
                </div>
              </div> 
              </div>
        </div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.playout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel\resources\views/admin/playout/showname.blade.php ENDPATH**/ ?>