
<?php $__env->startSection('main'); ?>
 <section class="checkout spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h6><span class="icon_tag_alt"></span> Đăng Ký
                    </h6>
                </div>
            </div>
            <div class="checkout__form">
                <h4><?php if(count($errors)>0): ?>
                  <a>
                  	<?php $__currentLoopData = $errors->all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  	<?php echo e($err); ?>

                  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </a>
                <?php endif; ?>
                <?php if(Session::has('success')): ?>
                <a><?php echo e(Session::get('success')); ?></a>
                <?php endif; ?>
            </h4>
                
                <form action="<?php echo e(route('home.register')); ?>" method="POST" role="form">
                	<?php echo csrf_field(); ?> 
                    <div class="row">
                        <div class="col-lg-8 col-md-6">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="checkout__input">
                                        <p>Họ Và Tên<span>*</span></p>
                                        <input type="text" name="name">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="checkout__input">
                                        <p>Username<span>*</span></p>
                                        <input type="text" name="username">
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" value="0" name="active">
                            <div class="checkout__input">
                                <p>Địa chỉ<span>*</span></p>
                                <input type="text" name="adress">
                            </div>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="checkout__input">
                                        <p>Phone<span>*</span></p>
                                        <input type="text" name="phone">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="checkout__input">
                                        <p>Email<span>*</span></p>
                                        <input type="email" name="email">
                                    </div>
                                </div>
                            </div>
                            <div class="checkout__input">
                                <p>Password<span>*</span></p>
                                <input type="text" name="passa">
                            </div>
                            <div class="checkout__input">
                            	<input type="submit" value="Đăng Ký" name="register" style="color: #dc3545">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('playout.playout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel\resources\views/pages/login.blade.php ENDPATH**/ ?>