
<?php $__env->startSection('content'); ?>
<h1><?php echo e($masser); ?></h1>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.playout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel\resources\views/admin/playout/messer.blade.php ENDPATH**/ ?>